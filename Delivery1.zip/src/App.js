import React, { createContext, useReducer, useState } from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import './App.css'
import Header from './components/Header'
import Page1 from './pages/Page1'
import Page2 from './pages/Page2'
import Page3 from './pages/Page3'
import Page4 from './pages/Page4'
import Sidebar from './components/Sidebar'

const store = createContext()
const { Provider } = store
export { store }
const App = () => {
  const [isBackground, setIsBackground] = useState(false)
  const [state, dispatch] = useReducer((state, action) => {
    switch (action.type) {
      case "UpdateBetAmount":
        return {
          ...state,
          betAmount: parseFloat(action.payload)
        }
      case "UpdateFlipResult":
        return {
          ...state,
          flipResult: action.payload
        }
      case "UpdateSelected":
        return {
          ...state,
          selectedCoinFace: action.payload
        }
      case "toggleAudioState":
        return {
          ...state,
          muted: !state.muted
        }
      default:
        return state
    }
  }, {
    betAmount: 2,
    flipResult: "",
    selectedCoinFace: "",
    betInterval: 0.1,
    maxBet: 3,
    minBet: 1,
    multiplier: 1.95,
    muted: false
  })
  return (
    <div className={`App ${isBackground && 'gray-bg'}`} >

      <audio controls autoPlay hidden muted={state.muted}>
        <source src={require("./assets/sound.mp3")} type="audio/mpeg" />unsupported !!</audio>
      <Provider value={{ state, dispatch }}>
        <BrowserRouter>
          <Header isBackground={isBackground} setIsBackground={setIsBackground} />
          <Sidebar />
          <Routes>
            <Route path="/" element={<Page1 />} />
            <Route path="/flip" element={<Page2 />} />
            <Route path="/won" element={<Page3 />} />
            <Route path="/lost" element={<Page4 />} />
          </Routes>
        </BrowserRouter>
      </Provider>
    </div>
  )
}

export default App