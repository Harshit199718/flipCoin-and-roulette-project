import React, { useContext, useState } from 'react';
import { store } from '../App';
import './Header.css'

const Header = ({ setIsBackground, isBackground }) => {
    const { dispatch } = useContext(store)
    return (
        <>
            <header id="header">
                <div className="logo">
                    <img src={require("../assets/img/logo.jpg")} width="114px" height="113px" alt="" />
                </div>
                <div className="side-bar">
                    <div className="side-icon">

                        <button className="icon-btn" onClick={() => dispatch({type:"toggleAudioState"})}><img src={require("../assets/img/icon1.png")} alt="" width="18.67px" height="12.27px" /></button>
                        <button className="icon-btn icon2" onClick={() => { setIsBackground(!isBackground) }}><img src={require("../assets/img/icon2.png")} alt="" width="22.89px"
                            height="16.73px" /></button>
                        <button className="icon-btn icon3"><img src={require("../assets/img/icon3.png")} alt="" width="27.11px"
                            height="26.77px" /></button>
                    </div>
                    <div className="side-connect-btn">
                        <button className="connect-btn">Connect Wallet</button>
                    </div>
                </div>

            </header>
        </>
    )
}

export default Header