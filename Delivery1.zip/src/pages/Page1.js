import React, { useContext } from 'react'
import Lottie from "lottie-react";
import { useNavigate } from 'react-router-dom'
import { store } from '../App'
import CoinRotate from "../assets/lottie/#03_Coin 3D Rotation Animation 02.json"
import './Page1.css'

const Page1 = () => {
  const { state, dispatch } = useContext(store)
  const navigate = useNavigate()
  return (
    <div className="layer1">
      <Lottie animationData={CoinRotate} loop={true} style={{ width: "217px", height: "217px" }} />
      <div className="point">
        <span>X</span> &nbsp;
        <span>{state.multiplier}</span>
      </div>
      <div className="toss-btn">
        <button className={state.selectedCoinFace == "Head" ? "selected-face" : ""} onClick={() => {
          dispatch({
            type: "UpdateSelected",
            payload: "Head"
          })
        }}>
          <div className="effect7 btn-background">
          </div>
          Head<div></div></button>
        <button className={state.selectedCoinFace == "Tail" ? "selected-face" : ""} onClick={() => {
          dispatch({
            type: "UpdateSelected",
            payload: "Tail"
          })
        }}>
          <div className="effect7 btn-background">
          </div> Tail <div></div></button>
      </div>
      <p>Bet Amount</p>
      <div className="sol">
        <button onClick={() => {
          dispatch({
            type: "UpdateBetAmount",
            payload: parseFloat(state.betAmount - state.betInterval).toFixed(2)
          })
        }}><i className="fa fa-minus-circle" aria-hidden="true"></i></button>
        <span>{state.betAmount} SOL</span>
        <button onClick={() => {
          dispatch({
            type: "UpdateBetAmount",
            payload: parseFloat(state.betAmount + state.betInterval).toFixed(2)
          })
        }}><i className="fa fa-plus-circle" aria-hidden="true"></i></button>
      </div>
      <div className="min-max">
        <button onClick={() => {
          dispatch({
            type: "UpdateBetAmount",
            payload: state.minBet
          })
        }}>MIN</button>&nbsp;
        <button onClick={() => {
          dispatch({
            type: "UpdateBetAmount",
            payload: state.maxBet
          })
        }}>MAX</button>
      </div>
      <button className="flip-btn" disabled={!state.selectedCoinFace} onClick={() => {
        navigate("/flip")
      }}>Flip<div></div></button>
      <p flip-bottom-text>Flip the coin and win 0.39 Sol</p>
    </div>
  )
}

export default Page1