import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { store } from '../App';
import './Page3.css';

const Page3 = () => {
    const navigate = useNavigate()
    const { state, dispatch } = useContext(store)
    return (
        <>
            <div className="layer1">
                <h1>Coin Revealed</h1>
                <div className="coin-img">
                    <img src={require("../assets/img/coin.png")} alt="" />
                    <span className="coin-side">{state.flipResult}</span>
                </div>
                <h1 className="won-msg">Congrates<br />
                    you won {state.betAmount * state.multiplier} sol
                </h1>
                <button className="flip-more" onClick={() => navigate("/")}>Flip More<div></div></button>
            </div>
        </>
    )
}

export default Page3