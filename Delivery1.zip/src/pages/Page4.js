import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { store } from '../App';
import './Page4.css';

const Page4 = () => {
    const navigate = useNavigate()
    const { state, dispatch } = useContext(store)
    return (
        <>
            {/* <!-- Card Section --> */}

            <div className="layer1">
                <h1>Coin Revealed</h1>
                <div className="coin-img">
                    <img src={require("../assets/img/coin.png")} alt="" />
                    <span className="coin-side">{state.flipResult}</span>
                </div>
                <h1 class="msg">You lost</h1>
                <button className="flip-more" onClick={() => navigate("/")}>Flip More<div></div></button>
            </div>
        </>
    )
}

export default Page4