import React, { useContext } from 'react';
import { store } from '../App';
import './Header.css'
import HeaderIcon from './HeaderIcon';

const Header = ({ }) => {
    const { state, dispatch } = useContext(store)
    return (
        <>
            <header id="header">
                <div className="toggle-btn">
                    <img src={require("../assets/img/bar.png")} alt="" onClick={() => document.getElementById('sideBar').classList.toggle('active')} />
                </div>
                <div className="logo">
                    <img src={require("../assets/img/logo.png")} width="100px" height="100px" alt="" />
                </div>
                <div className="side-bar">
                    <HeaderIcon />
                    <div className="side-connect-btn">
                        <button className="connect-btn connect-text-lg">Connect Wallet</button>
                        <button className="connect-btn connect-text">Connect</button>
                    </div>
                </div>

            </header>
        </>
    )
}

export default Header