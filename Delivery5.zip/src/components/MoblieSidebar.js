import React, { useContext } from 'react'
import { store } from '../App'
import "./MobileSidebar.css"
function MoblieSidebar() {
    const { state, dispatch } = useContext(store)
    return (
        <>
            <div class="nav-right visible-xs">
                <div id="button-toggle" className='active show-cross' onClick={()=>{
                    dispatch({
                        type:"toggleMobileSidebar",
                        payload:false
                    })
                }}>
                    <div class="bar top"></div>
                    <div class="bar middle"></div>
                    <div class="bar bottom"></div>
                </div>
            </div>
            <div class="sidebar-mobile">
                <ul class="sidebar-list">
                    <li class="sidebar-item active"><a class="sidebar-anchor" onClick={e => e.preventDefault()}>CoinFlip</a></li>
                    <li class="sidebar-item active"><a class="sidebar-anchor" onClick={e => e.preventDefault()}>Roulette</a></li>
                    <li class="sidebar-item active"><a class="sidebar-anchor" onClick={e => e.preventDefault()}>About us</a></li>
                    <li class="sidebar-item active"><a class="sidebar-anchor" onClick={e => e.preventDefault()}>White Paper</a></li>
                    <li class="sidebar-item active"><a class="sidebar-anchor" onClick={e => e.preventDefault()}>Twitter</a></li>
                </ul>
            </div>
        </>
    )
}

export default MoblieSidebar